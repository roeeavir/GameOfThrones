

/*Name: Roee Aviran
ID: 316492644 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		Scanner input = new Scanner(System.in);
		//First of all the players are asked to insert the value of X - The size of the board.
		System.out.println("********** GAME OF THRONE BOARD X * X **********");
		int choice = 0;
		System.out.println("PICK YOUR GAME DEFINING STYLE(1 OR 2):\n1. Enter Parameters By User."
				+ "\n2. Load Parameters From File.\r\n");
		choice = input.nextInt();
		if (choice == 2) {
			System.out.println("PARAMETERS WILL BE ADDED BY FILE!");
			System.out.println("Enter Path To File:");
			String path = input.next();
			fileParameters(path);
		}else if (choice == 1) {
			System.out.println("PARAMETERS WILL BE ADDED BY USER!");
			System.out.println("ENTER BOARD SIZE:");
			int size = input.nextInt();
			userParameters(size);
		}
		
		System.out.println("**********END OF GAME**********");
		
		input.close();

	}
	
	public static void choiceOfDefining(int choice, int size) {
		if (choice == 2) {
			
			
		}else if (choice == 1) {
			
			userParameters(size);
		}else {
			System.out.println("BAD INPUT!\nPICK YOUR CHOICE WITH THE NUMBERS '1' OR '2'!");
		}
	}
	
	public static void userParameters(int size) {
		GameOfThrones got = new GameOfThrones(size);
		System.out.printf("THE BOARD SIZE IS %d X %d\n", size , size);
		System.out.println("ATTENTION!\n THE X VARIABLES ARE FOR THE X AXIS (LEFT & RIGHT)"
				+ " AND THE Y VARIABLES ARE FOR THE Y AXIS (UP & DOWN)");
		String team = "RED";// The red team will go first, and will pick their characters first.
		boolean direction;// A boolean value that will help define the direction in which the soldiers will advance to.
		
		direction = true; // In this case the soldiers will advance down.
		got.userSetSoldier(team, direction, size);
		got.userSetDragon(team, direction, size);
		direction = false; // In this case the soldiers will advance up.
		
		team = "BLUE"; // The right to pick characters has passed to the blue team.
		got.userSetSoldier(team, direction, size);
		got.userSetDragon(team, direction, size);
		advanceGame(got);
	}
	
	public static void fileParameters(String path) throws FileNotFoundException {
		File f = new File(path);
		Scanner s = new Scanner(f);
		Scanner hashReader = new Scanner(f);
		int size = s.nextInt();
		GameOfThrones got = new GameOfThrones(size);
		boolean direction = true;
		String team = s.next();
		got.fileSetSoldier(team, direction, size, s);
		got.fileSetDragon(team, direction, size, s);
		direction = false;
		team = s.next();
		got.fileSetSoldier(team, direction, size, s);
		got.fileSetDragon(team, direction, size, s);
		boolean isFileUsuable = got.hashCodeCheck(hashReader, s);
		if (isFileUsuable) {
			advanceGame(got);
		}
		s.close();
	}
	
	public static void advanceGame(GameOfThrones got) {
		System.out.println("***************************************");
		got.boardOutLine();// A function for defining the outline of the board.
		int i = 1;
		got.printBoard(i);// A function for printing the board itself to the console.
		
		do {
			i++;
			got.advanceStep();// A function for advancing each and every piece on the board (Red dragons, blue dragons, red soldiers, blue soldiers).
			got.printBoard(i);
			got.setGameOver();// A function that checks if the game should continue or come to an end.
		}while (!(got.getGameOver()));
	}
	
	

}



