

/*Name: Roee Aviran
ID: 316492644 */

import java.util.Scanner;


public class GameOfThrones {
	
	//variables
	private String[][] board;// The board in which the game will unfold.
	private Dragon[] dragons;// Array of dragons
	private Soldier[] soldiers;// Array of dragons
	private boolean gameOver;// Boolean variable for ending the game.
	private int lastSoldier = 0;// The amount of added soldiers.
	private int lastDragon = 0;// The amount of added dragons.

	public GameOfThrones(int size) {
		gameOver = false;// As long as the gameOver variable is false, the game will continue. 
		this.board = new String[size + 2][size + 2];// The board will have to be 2 sizes larger than the player has inserted, to make the borderline.
		this.soldiers = new Soldier[size * 4];// The max number of soldiers is equal to the first 2 lines of the board for each player(not including the borderline).
		this.dragons = new Dragon[size * 4]; // The max number of dragons is equal to the first 2 lines of the board for each player(not including the borderline).
	}

	public String[][] getBoard() {
		return board;
	}

	public void addSoldier(int x, int y, String team, boolean direction, String name) {// A method for adding a dragon the the dragons array
		Soldier soldier = new Soldier(x, y, team, direction, name);// Constructs a new soldier.
		this.soldiers[this.lastSoldier] = soldier;// Inserts the soldier into an array of its own class.
		this.lastSoldier++;// The index for the soldiers array, in case there will be a next soldier.
		this.board[soldier.getYPos()][soldier.getXPos()] = name;// The name of the soldier, which will be shown on the game board.
	}

	public void addDragon(int x, int y, String team, boolean direction, String name) {// A method for adding a dragon the the dragons array
		Dragon dragon = new Dragon(x, y, team, direction, name);// Constructs a new dragon.
		this.dragons[this.lastDragon] = dragon;// Inserts the dragon into an array of its own class.
		this.lastDragon++;// The index for the dragons array, in case there will be a next dragon.
		this.board[dragon.getYPos()][dragon.getXPos()] = name;// The name of the dragon, which will be shown on the game board.
	}
	
	public void userSetSoldier(String team, boolean direction, int size) {
		Scanner s = new Scanner(System.in);
		System.out.printf("******** %s PLAYER CHARACTER CREATION ********\n", team);
		System.out.printf("ENTER NUMBER OF %s SOLDIERS (The number of soldiers cannot be greater than %d):\n", team, size*2);
		int numOfSol = s.nextInt();// Number of wanted soldiers.
		int x, y;
		String name;
		for (int i = 1; i <= numOfSol; i++) {
			System.out.printf("--- ENTER SOLDIER %d INFO ---\nENTER X VALUE: ", i);
			x = s.nextInt();
			System.out.println("ENTER Y VALUE:");
			y = s.nextInt();
			name = team + "_Sol" + Integer.toString(i);
			addSoldier(x + 1, y + 1, team, direction, name);
			System.out.println("SOLDIER CREATED SUCCESSFULLY!");

		}

	}
	
	public void fileSetSoldier(String team , boolean direction, int size, Scanner s) {
		int numOfSol = s.nextInt();
		int x, y;
		String name;
		for (int i = 1; i <= numOfSol; i++){
			y = s.nextInt();
			x = s.nextInt();
			name = team + "_Sol" + Integer.toString(i);
			addSoldier(x + 1, y + 1, team, direction, name);
			System.out.println("SOLDIER CREATED SUCCESSFULLY!");
		}
	}

	public void userSetDragon(String team, boolean direction, int size) {
		Scanner scn = new Scanner(System.in);
		System.out.printf("ENTER NUMBER OF %s DRAGONS (the number of dragons cannot be greater than %d):\n", team, size*2);
		int numOfDrag = scn.nextInt();// Number of wanted dragons.
		int x, y;
		String name;
		for (int i = 1; i <= numOfDrag; i++) {
			System.out.printf("--- ENTER DRAGON %d INFO ---\nENTER X VALUE: ", i);
			x = scn.nextInt();
			System.out.println("ENTER Y VALUE:");
			y = scn.nextInt();
			name = team + "_Drag" + Integer.toString(i);
			addDragon(x + 1, y + 1, team, direction, name);
			System.out.println("DRAGON CREATED SUCCESSFULLY!");

		}

	}
	
	public void fileSetDragon(String team , boolean direction, int size, Scanner s) {
		int numOfDrag = s.nextInt();
		int x, y;
		String name;
		for (int i = 1; i <= numOfDrag; i++){
			y = s.nextInt();
			x = s.nextInt();
			name = team + "_Drag" + Integer.toString(i);
			addDragon(x + 1, y + 1, team, direction, name);
			System.out.println("DRAGON CREATED SUCCESSFULLY!");
		}
	}


	public void advanceStep() {// A method for making each and every piece in the game advance in a way that follows the game rules.

		for (int i = 0; i < this.dragons.length; i++) {
			if (this.dragons[i] == null) {
				continue;
			}
			advanceDragon(i);

		}

		for (int i = 0; i < this.soldiers.length; i++) {
			if (this.soldiers[i] == null) {
				continue;
			}
			if (advanceSoldier(i)) {
				break;
			}
		}
	}
	public void advanceDragon(int i) {
		for (int step = 0; step < 3; step++) {
			dragons[i].setStep(step);
			int nextX = this.dragons[i].getNextX();// a variable that gets the next position of the dragon on the board for the x axis.
			int nextY = this.dragons[i].getNextY();// a variable that gets the next position of the dragon on the board for the y axis.
			String team = this.dragons[i].getTeam();// a variable that gets the team of the dragon that is being checked.
			String name = this.dragons[i].getName();// a variable that gets the name of the dragon that is being checked.
			nextX = dragonPassesBoundariesX(nextX);
			nextY = dragonPassesBoundariesY(nextY);

			// Dragon or soldier from opposing after next move
			if (!(board[nextY][nextX].contains("*")) && !(board[nextY][nextX].contains(team))) {
				if (board[nextY][nextX].contains("Drag")) {// Checks if the next position of the dragon will contain an opposing dragon.
					dragonMeetsDragon(name, nextY, nextX, i);
					break;// For making the loop stop.

				}

				else if (board[nextY][nextX].contains("Sol")) {// Checks if the next position of the dragon will contain an opposing soldier.
					dragonMeetsSoldier(name, nextY, nextX, i);
					dragons[i].setXPos(nextX);
					dragons[i].setYPos(nextY);
					break;// For making the loop stop.
				}
			} else if (board[nextY][nextX].contains(team)) {
				break;// For making the loop stop.
				// Ally meets ally and does nothing. cannot move.
			}

			else {
				dragonFlys(nextY, nextX, i);
			}
		}
	}
	
	public boolean advanceSoldier(int i) {
		int nextX = this.soldiers[i].getNextX();// a variable that gets the next position of the soldier on the board for the x axis.
		int nextY = this.soldiers[i].getNextY();// a variable that gets the next position of the soldier on the board for the y axis.
		String team = this.soldiers[i].getTeam();// a variable that gets the team of the soldier that is being checked.
		String name = this.soldiers[i].getName();// a variable that gets the name of the soldier that is being checked.

		// Dragon or soldier from opposing after next move
		if (!(board[nextY][nextX].contains("*")) && !(board[nextY][nextX].contains(team))) {
			if (board[nextY][nextX].contains("Drag")) {// Checks if the next position of the soldier will contain an opposing dragon.
				soldierMeetsDragon(name, i);
				
			}

			else if (board[nextY][nextX].contains("Sol")) {// Checks if the next position of the soldier will contain an opposing soldier.
				soldierMeetsSoldier(name, nextY, nextX, i);
				
			}
		} else if (board[nextY][nextX].contains(team)) {
			// Ally meets ally and does nothing. cannot move.
		}

		else {
			soldierWalks(nextY, nextX, i);
			if (this.soldiers[i].getYPos() == board.length - 2 && this.soldiers[i].getName().contains("RED") || 
					this.soldiers[i].getYPos() == 1 && this.soldiers[i].getName().contains("BLUE")) {
				return true;
			}
		}
		
		return false;
	}
	
	public void soldierWalks(int nextY, int nextX, int i) {// A method for making a soldier advance a step.
		board[this.soldiers[i].getYPos()][this.soldiers[i].getXPos()] = "*";
		this.soldiers[i].setYPos(nextY);
		board[nextY][nextX] = soldiers[i].getName();
	}
	
	public void dragonFlys(int nextY, int nextX, int i) {// A method for making a dragon advance a step.
		board[this.dragons[i].getYPos()][this.dragons[i].getXPos()] = "*";
		this.dragons[i].setXPos(nextX);
		this.dragons[i].setYPos(nextY);
		board[nextY][nextX] = dragons[i].getName();
	}
	
	public void soldierMeetsSoldier(String name, int nextY, int nextX, int i) {// A method for when a soldier meets and enemy soldier.
		int enemy = getIndexOfPiece(nextX, nextY, 0);
		System.out.printf("\n%s AND %S HAVE BOTH DIED AND REMOVED FROM THE BOARD!\n", board[nextY][nextX], name);
		board[soldiers[i].getYPos()][soldiers[i].getXPos()] = "*";
		soldiers[i] = null;
		board[nextY][nextX] = "*";
		soldiers[enemy] = null;
	}
	
	public void soldierMeetsDragon(String name, int i) {// A method for when a soldier meets and enemy dragon.
		board[this.soldiers[i].getYPos()][this.soldiers[i].getXPos()] = "*";
		System.out.printf("\n%s HAS DIED AND REMOVED FROM THE BOARD!\n", name);
		board[soldiers[i].getYPos()][soldiers[i].getXPos()] = "*";
		soldiers[i] = null;
	}
	
	public void dragonMeetsDragon(String name, int nextY, int nextX, int i) {// A method for when a dragon meets and enemy dragon.
		int enemy = getIndexOfPiece(nextX, nextY, 1);
		System.out.printf("\n%s AND %S HAVE BOTH DIED AND REMOVED FROM THE BOARD!\n", board[nextY][nextX], name);
		board[dragons[i].getYPos()][dragons[i].getXPos()] = "*";
		dragons[enemy] = null;
		board[nextY][nextX] = "*";
		dragons[i] = null;
	}
	
	public void dragonMeetsSoldier(String name, int nextY, int nextX, int i) {// A method for when a dragon meets and enemy soldier.
		int enemy = getIndexOfPiece(nextX, nextY, 0);
		System.out.printf("\n%s HAS DIED AND REMOVED FROM THE BOARD!\n", board[nextY][nextX]);
		board[this.dragons[i].getYPos()][this.dragons[i].getXPos()] = "*";
		board[nextY][nextX] = this.dragons[i].getName();
		soldiers[enemy] = null;
	}
	
	private int getIndexOfPiece(int x, int y, int soldierOrDragon) {// A private method for finding the index of an enemy piece.
		if (soldierOrDragon == 0) {// The value of a soldier.
			for (int i = 0; i < soldiers.length; i++) {
				if (soldiers[i] != null && soldiers[i].getXPos() == x && soldiers[i].getYPos() == y) {
					return i;
				}
			}
		} else {// As long as the variable "soldierOrDragon" is not equal to 0, the opposing piece is a dragon.
			for (int i = 0; i < dragons.length; i++) {
				if (dragons[i] != null && dragons[i].getXPos() == x && dragons[i].getYPos() == y) {
					return i;
				}
			}
		}
		return -1;// -1 isn't a possible index, there for getting it will mean there is a problem with the software.
	}
	
	public int dragonPassesBoundariesY(int nextY) {
		// A method for allowing the dragon to pass through 1 end of the board to another on the y axis.
		if (nextY < 1) {			
			nextY = board.length-2;
			return nextY;
		}
		if (nextY > board.length-2) {
			nextY = 1;
			return nextY;
		}
		return nextY;
	}
	
	public int dragonPassesBoundariesX(int nextX) {
		// A method for allowing the dragon to pass through 1 end of the board to another on the x axis.
		if (nextX < 1) {
			nextX = board.length-2;
			return nextX;
		}
		if (nextX > board.length-2) {
			nextX = 1;
			return nextX;
		}
		return nextX;
	}

	public void boardOutLine() {// A method for printing the borderline of the board.
		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board.length; j++) {
				if (i == j && i == 0 || i == j && i == board.length - 1 || i == board.length - 1 && j == 0
						|| j == board.length - 1 && i == 0) {
					board[i][j] = " ";
				} else if (i == 0 || i == board.length - 1) {
					board[i][j] = Integer.toString(j - 1);
				} else if (j == 0 || j == board.length - 1) {
					board[i][j] = Integer.toString(i - 1);
				} else if (board[i][j] == null) {
					board[i][j] = "*";
				}
			}
		}

	}

	
	public void printBoard(int count) {// A method for printing the board.
		System.out.printf(
				"------------------------------------------------------------------------ STEP %d --------------"
				+ "----------------------------------------------------------\n",
				count);
		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board.length; j++) {
				if (board[i][j].length() > 3) {
					System.out.print("   " + board[i][j] + " ");
				} else {
					System.out.print("\t" + board[i][j]);
				}
				System.out.print("\t");

			}
			System.out.println("\n");
		}
	}

	public void setGameOver() {
		int numOfLivingSol = 0;
		for (int i = 0; i < soldiers.length; i++) {
			if (this.soldiers[i] == null) {
				continue;
			}
			if (this.soldiers[i].getYPos() == board.length - 2 && this.soldiers[i].getName().contains("RED")) {
				/* Checks if a red soldier has arrived at the end of the board, if so, the gameOver variable will
				 *  return true, and the game will end with the red team winning. */
				System.out.println("RED TEAM WINS!");
				gameOver = true;
				break;
			} if (this.soldiers[i].getYPos() == 1 && this.soldiers[i].getName().contains("BLUE")) {
				/* Checks if a blue soldier has arrived at the end of the board, if so, the gameOver variable will
				 *  return true, and the game will end with the blue team winning. */
				System.out.println("BLUE TEAM WINS!");
				gameOver = true;
				break;
			}
		}
		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board.length; j++) {
				if (board[i][j].contains("Sol")) {// Checks if there are any soldiers left on the board.
					numOfLivingSol++;
				}
				if (numOfLivingSol > 0) {
					break;
				}
			}
		}
		if (numOfLivingSol == 0) {// If there are no soldiers, the gameOver variable will return true, and the game will end.
			System.out.println("THE GAME HAS ENDED IN A TIE! :O");
			gameOver = true;
		}

	}
	
	public boolean getGameOver() {
		return this.gameOver;
	}
	
	public boolean hashCodeCheck(Scanner hashReader, Scanner s) {/* Comparing between the wanted 
	hashCode and the existing hashCode - If they are equal the game will begin, if not the game will not begin. */
		int wantedCode = wantedHashCode(s);
		int existingCode = hashCodeRead(hashReader);
		if (wantedCode == existingCode) {
			System.out.println("THE EXISTING HASHCODE IS THE SAME AS THE WANTED ONE - LET THE GAME BEGINE!");
			return true;
		}else {
			System.err.println("DAMAGED INPUT FILE!");
			return false;
		}
	}
	public int wantedHashCode(Scanner hashReader) {// Setting the value of the wanted hashCode to a variable.
		int fileHashCode = hashReader.nextInt();
		System.out.printf("HASHCODE LOADING...\nLoaded HashCode: %d\n", fileHashCode);
		return fileHashCode;
	}
	public int hashCodeRead(Scanner hashReader) {// A method for reading the text of the file and setting it into a string.
		String sumOfText = "";
		while(hashReader.hasNextLine()) {/* A loop with a temporary variable and stopping value, to
			evade adding the last line of the text into the String */
			String temp = hashReader.nextLine();
			if (!(hashReader.hasNextLine())) {
				break;
			}
			sumOfText += temp;
		}
		int existingHashCode = hashCodeRicursion(sumOfText);
		System.out.printf("GENERATED FILE HASHCODE - %d\n", existingHashCode);
		return existingHashCode;
		
	}
	public int hashCodeRicursion(String sumOfText) {// A recursive method for calculating the sum of the ascii values of the text.
		int asciiSum = 0;
		if (sumOfText.length() == 1) {
			return (int)sumOfText.charAt(0);
		}
			asciiSum += (int)(sumOfText.charAt(0));
		return hashCodeRicursion(sumOfText.substring(1, sumOfText.length())) + asciiSum;
		
		
	}	

}