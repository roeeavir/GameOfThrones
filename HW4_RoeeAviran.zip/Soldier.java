

/*Name: Roee Aviran
ID: 316492644 */

public class Soldier {
	public static int id = 0;
	//variables
	private int xPos;// Defining the x axis of the soldier on the board.
	private int yPos;// Defining the y axis of the soldier on the board.
	private String name;// Name of the soldier.
	private String team;// Team of the soldier.
	private boolean direction;// the direction which the soldier will walk to.
	
	public Soldier(int x, int y, String team, boolean direction, String name) {
		this.xPos = x;
		this.yPos = y;
		this.team = team;
		this.direction = direction;
		this.name = name;
		Soldier.id = id++;
	}
	
	
	public int getXPos()
	{
		return this.xPos;
	}

	public int getYPos()
	{
		return this.yPos;
	}
	
	public void setXPos(int x)
	{
		this.xPos = x;
	}

	public void setYPos(int y)
	{
		this.yPos = y;
	}
	
	public int getNextX()//does not change for the soldier.
	{
		return this.xPos;
	}

	public int getNextY()// Gives the next position on the y axis, which the soldier will walk to.
	{
		if (this.direction)
		{
			return this.yPos + 1;
		}
		else
		{
			return this.yPos - 1;
		}	}
	
		
	public String getTeam()
	{
		return this.team;
	}
	
	public String getName(){
		return this.name;
	}
}