

/*Name: Roee Aviran
ID: 316492644 */

import java.util.Random;

public class Dragon {
	public static int id = 0;
	//variables
	private int xPos;// Defining the x axis of the dragon on the board.
	private int yPos;// Defining the y axis of the dragon on the board.
	private String name;// Name of the dragon.
	private String team;// Team of the dragon.
	private boolean direction;// the direction which the dragon will walk to.
	private int stepNumber = 0;


	public Dragon(int x, int y, String team, boolean direction, String name) {
		this.xPos = x;
		this.yPos = y;
		this.team = team;
		this.direction = direction;
		this.name = name;
		Dragon.id = id++;
	}
	
	public int getXPos()
	{
		return this.xPos;
	}

	public int getYPos()
	{
		return this.yPos;
	}
	
	public void setXPos(int x)
	{
		this.xPos = x;
	}

	public void setYPos(int y)
	{
		this.yPos = y;
	}
	
	public int getNextY()// Gives the next position on the y axis, which the dragon will fly to.
	{
		int nextYPosition = this.yPos;
		if (this.stepNumber == 0 || this.stepNumber == 2)// The dragon advances on the y axis twice each turn.
		{
			if (this.direction)
			{
				nextYPosition++;
			}
			
			else
			{
				nextYPosition--;
			}
		}
		
		return nextYPosition;
	}

	public int getNextX()// Gives the next position on the x axis, which the dragon will fly to.
	{
		int nextXPosition = this.xPos;
		
		if (this.stepNumber == 1)
		{
			Random r = new Random();
			
			if(r.nextBoolean())// The dragon will advance, once each turn, on the x axis randomly.
			{
				nextXPosition++;
			}
			
			else
			{
				nextXPosition--;
			}
		}
		
		return nextXPosition;
	}
	
	public String getTeam()
	{
		return this.team;
	}
	
	public String getName(){
		return this.name;
	}
	public void setStep(int step) {// sets the step number in the order the dragon advances (0 and 2 for the y axis, 1 for the x axis).
		this.stepNumber = step;
	}
	
	
}
